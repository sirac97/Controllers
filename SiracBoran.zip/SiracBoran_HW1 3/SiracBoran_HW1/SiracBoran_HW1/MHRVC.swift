//
//  MHRVC.swift
//  SiracBoran_HW1
//
//  Created by CTIS Student on 26.10.2021.
//  Copyright © 2021 CTIS. All rights reserved.
//

import UIKit

class MHRVC: UIViewController {
    
    
    @IBOutlet weak var ageTextField: UITextField!
    @IBOutlet weak var mSegmentedControl: UISegmentedControl!
    @IBOutlet weak var mLabel: UILabel!
    
    var gender = "Male"
    
    
    func mhrFormula(gender: Int, age: Double) -> Double {
        if gender == 0 {
            return (203.7 / (1.0 + exp(0.033 * (age - 104.3))))
        }
        else {
            return (190.2 / (1.0 + exp(0.0453 * (age - 107.5))))
        }
    }
    
    
    
    @IBAction func onSegmentedControl(_ sender: UISegmentedControl) {
        switch mSegmentedControl.selectedSegmentIndex{
        case 0:
            mLabel.text = "Gender(male):"
        case 1:
            mLabel.text = "Gender(female):"
        default:
            break
        }
    }
    
    
    
    @IBAction func calculateMhr(_ sender: Any) {
        if ageTextField.text!.isEmpty{
            let alert = UIAlertController(title: "Error message", message: "Age field cant be empty",preferredStyle:  .alert)
            alert.addAction(UIAlertAction(title: NSLocalizedString("Close",comment: "Default action"), style: .default, handler: {
                _ in NSLog("OK")
            }))
            self.present(alert, animated: true, completion: nil)
        }
        else
        {
            let age = Double(ageTextField.text!)!
            switch mSegmentedControl.selectedSegmentIndex{
            case 0:
                let mhrformula = 203.7 / (1.0 + exp(0.033 * (age - 104.3)))
                let mhrstyle = String (format: "%0.2f",mhrformula)
                let fatRangeStart = mhrformula * 50 / 100
                let fatRangeEnd = mhrformula * 70 / 100
                let cardioStart = mhrformula * 70 / 100
                let cardioEnd = mhrformula * 80 / 100
            
                let maleAlert = "MHR" + mhrstyle + "BPM \n Fatburning range = (" + String(format:"%0.0f", fatRangeStart) + "--" + String(format:"%0.0f",fatRangeEnd) + ")\n Cardiovascular range = (" + String(format:"%0.0f", cardioStart) + "--" +
                    String(format:"%0.0f", cardioEnd) + ")"
                let alert = UIAlertController(title:"Male results",message:maleAlert, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: NSLocalizedString("Close",comment: "Default action"), style: .default, handler: { _ in
                    NSLog("OK")
                }))
                self.present(alert, animated: true, completion: nil)
                
            default:
                let mhrformula = 190.2 / (1.0 + exp(0.0453 * (age - 107.5)))
                let mhrstyle = String (format: "%0.2f",mhrformula)
                let fatRangeStart = mhrformula * 50 / 100
                let fatRangeEnd = mhrformula * 70 / 100
                let cardioStart = mhrformula * 70 / 100
                let cardioEnd = mhrformula * 80 / 100
                let femaleAlert = "MHR" + mhrstyle + "BPM \n Fatburning range = (" + String(format:"%0.0f", fatRangeStart) + "--" + String(format:"%0.0f",fatRangeEnd) + ")\n Cardiovascular range = (" + String(format:"%0.0f", cardioStart) + "--" +
                    String(format:"%0.0f", cardioEnd) + ")"
                let alert = UIAlertController(title:"Male results",message:femaleAlert, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: NSLocalizedString("Close",comment: "Default action"), style: .default, handler: { _ in
                    NSLog("OK")
                }))
                self.present(alert, animated: true, completion: nil)
                
            }
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(false)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
