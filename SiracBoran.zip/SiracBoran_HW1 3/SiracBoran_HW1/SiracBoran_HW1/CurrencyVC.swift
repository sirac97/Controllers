//
//  CurrencyVC.swift
//  SiracBoran_HW1
//
//  Created by CTIS Student on 26.10.2021.
//  Copyright © 2021 CTIS. All rights reserved.
//

import UIKit

class CurrencyVC: UIViewController {
    
    
    @IBOutlet weak var image: UIImageView!
    @IBOutlet weak var mLabel1: UILabel!
    @IBOutlet weak var mLabel2: UILabel!
    @IBOutlet weak var onSegmentControl: UISegmentedControl!
    
    @IBOutlet weak var input: UITextField!
    @IBOutlet weak var input2: UITextField!
    let selection = 0
    
    @IBAction func onSegmentChange(_ sender: UISegmentedControl) {
        
        switch onSegmentControl.selectedSegmentIndex  {
        case 0:
            mLabel1.text = "TL(₺)"
            mLabel2.text = "USD ($)"
            image.image = UIImage(named: "tl_usd")
            input.text = ""
            input2.text = ""
            
        case 1:
            mLabel1.text = "TL(₺)"
            mLabel2.text = "EUR (€)"
            image.image = UIImage(named: "tl_euro")
            input.text = ""
            input2.text = ""
            
        case 2:
            mLabel1.text = "TL(₺)"
            mLabel2.text = "GBP (£)"
            image.image = UIImage(named: "tl_gbp")
            input.text = ""
            input2.text = ""
            
        default:
            break
        }
    }
    
    
    @IBAction func TapChange(_ sender: UITapGestureRecognizer) {
        if onSegmentControl.selectedSegmentIndex == 2{
            onSegmentControl.selectedSegmentIndex = 0
        }else {
            onSegmentControl.selectedSegmentIndex = onSegmentControl.selectedSegmentIndex + 1
        }
        switch onSegmentControl.selectedSegmentIndex  {
        case 0:
            mLabel1.text = "TL(₺)"
            mLabel2.text = "USD ($)"
            image.image = UIImage(named: "tl_usd")
            input.text = ""
            input2.text = ""
        case 1:
            mLabel1.text = "TL(₺)"
            mLabel2.text = "EUR (€)"
            image.image = UIImage(named: "tl_euro")
            input.text = ""
            input2.text = ""
        case 2:
            mLabel1.text = "TL(₺)"
            mLabel2.text = "GBP (£)"
            image.image = UIImage(named: "tl_gbp")
            input.text = ""
            input2.text = ""
            
        default:
            break
        }
        
        
    }
    
    
    
    @IBAction func changeInput(_ sender: UITextField) {
        var value1 = 0.0
        if(Double(input.text!)) != nil {
            value1 = Double(input.text!)!
        }
        switch onSegmentControl.selectedSegmentIndex{
        case 0:
            input2.text = String(format:"%0.2f",tl2usd(input: value1))
        case 1:
            input2.text = String(format:"%0.2f",tl2euro(input: value1))
        default:
            input2.text = String(format:"%0.2f",tl2gbp(input: value1))
        }
    }
    
    
    
    @IBAction func changeInput2(_ sender: UITextField) {
        var value2 = 0.0
        if(Double(input2.text!)) != nil{
            value2 = Double(input2.text!)!
        }
        switch onSegmentControl.selectedSegmentIndex{
        case 0:
            input.text = String(format:"%0.2f",usd2tl(input: value2))
        case 1:
            input.text = String(format:"%0.2f",euro2tl(input: value2))
        default:
            input.text = String(format:"%0.2f",gbp2tl(input: value2))
        }
    }
    
    
    
    
    
    
    
    func tl2usd(input: Double)-> Double {
        return input/6
    }
    
    func tl2euro(input: Double) -> Double {
        return input/11.2
    }
    func tl2gbp(input: Double) -> Double {
        return input/13.5
    }
    func usd2tl(input: Double) -> Double {
        return input*6
    }
    func euro2tl(input: Double) -> Double {
        return input*11.2
    }
    func gbp2tl(input: Double) -> Double {
        return input*13.5
    }
    
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(false)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
