//
//  ViewController.swift
//  SiracBoran_HW1
//
//  Created by CTIS Student on 26.10.2021.
//  Copyright © 2021 CTIS. All rights reserved.
//

import UIKit

class MainVC: UIViewController {
    
    
    
    @IBAction func unwindToMain(segue: UIStoryboardSegue){
        
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        if let mController = segue.destination as? AboutVC{
            mController.text = "This is a simple controller"
        }
    }



}

