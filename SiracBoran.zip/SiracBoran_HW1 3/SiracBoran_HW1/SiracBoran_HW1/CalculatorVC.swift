//
//  CalculatorVC.swift
//  SiracBoran_HW1
//
//  Created by CTIS Student on 26.10.2021.
//  Copyright © 2021 CTIS. All rights reserved.
//

import UIKit

class CalculatorVC: UIViewController {
    
    
    @IBOutlet weak var num1: UITextField!
    @IBOutlet weak var num2: UITextField!
    

    
    @IBAction func onClick(_ sender: UIButton) {
        var number1, number2: Double
        let mTitle = "Output"
        number1 = Double(num1.text!) ?? 0.0
        number2 = Double(num2.text!) ?? 0.0
        
        let result = number1 + number2
        
        let output = "\(number1) + \(number2) = \(result)"
        
        let mAlert = UIAlertController(title: mTitle, message: output, preferredStyle: .alert)
        
        mAlert.addAction(UIAlertAction(title: "Close", style: .default, handler: nil))
        // Displaying the Alert
        self.present(mAlert, animated: true, completion: nil)
    }
    
    
    @IBAction func onMinus(_ sender: UIButton) {
        
        var number1, number2: Double
        let mTitle = "Output"
        number1 = Double(num1.text!) ?? 0.0
        number2 = Double(num2.text!) ?? 0.0
        
        let result = number1 - number2
        
        let output = "\(number1) - \(number2) = \(result)"
        
        let mAlert = UIAlertController(title: mTitle, message: output, preferredStyle: .alert)
        
        mAlert.addAction(UIAlertAction(title: "Close", style: .default, handler: nil))
        // Displaying the Alert
        self.present(mAlert, animated: true, completion: nil)
    }
    
    
    
    @IBAction func onMultiply(_ sender: UIButton) {
        var number1, number2: Double
        let mTitle = "Output"
        number1 = Double(num1.text!) ?? 0.0
        number2 = Double(num2.text!) ?? 0.0
        
        let result = number1 * number2
        
        let output = "\(number1) * \(number2) = \(result)"
        
        let mAlert = UIAlertController(title: mTitle, message: output, preferredStyle: .alert)
        
        mAlert.addAction(UIAlertAction(title: "Close", style: .default, handler: nil))
        // Displaying the Alert
        self.present(mAlert, animated: true, completion: nil)
    }
    
    
    @IBAction func onSummation(_ sender: UIButton) {
        var number1, number2: Double
        let mTitle = "Output"
        number1 = Double(num1.text!) ?? 0.0
        number2 = Double(num2.text!) ?? 0.0
        
        let result = number1 / number2
        
        let output = "\(number1) / \(number2) = \(result)"
        
        let mAlert = UIAlertController(title: mTitle, message: output, preferredStyle: .alert)
        
        mAlert.addAction(UIAlertAction(title: "Close", style: .default, handler: nil))
        // Displaying the Alert
        self.present(mAlert, animated: true, completion: nil)
    }
    
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
